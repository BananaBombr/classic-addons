local T, C, L = select(2, ...):unpack()

if (GetLocale() ~= "frFR") then
	return
end