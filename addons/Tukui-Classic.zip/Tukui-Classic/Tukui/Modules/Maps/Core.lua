local T, C, L = select(2, ...):unpack()

local Maps = CreateFrame("Frame")

T["Maps"] = Maps
