-- TO BE COMPLETED!

local T, C, L = select(2, ...):unpack()
local Miscellaneous = CreateFrame("Frame")

T["Miscellaneous"] = Miscellaneous
