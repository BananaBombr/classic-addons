local T, C, L = select(2, ...):unpack()
local Inventory = CreateFrame("Frame")

T["Inventory"] = Inventory
