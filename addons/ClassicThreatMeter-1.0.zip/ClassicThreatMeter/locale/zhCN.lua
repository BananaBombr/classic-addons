local A, C, L, _ = unpack(select(2, ...))
if A.locale ~= "zhCN" then return end

-----------------------------
--	zhCN client
-----------------------------
-- main frame
L.gui.threat		= "威胁"

-- config frame
L.default			= "默认"
