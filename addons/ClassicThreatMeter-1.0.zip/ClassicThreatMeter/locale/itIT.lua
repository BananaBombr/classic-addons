local A, C, L, _ = unpack(select(2, ...))
if A.locale ~= "itIT" then return end

-----------------------------
--	itIT client
-----------------------------
-- main frame
L.gui.threat		= "Minaccia"

-- config frame
L.default			= "Predefinito"
