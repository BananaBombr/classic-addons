local A, C, L, _ = unpack(select(2, ...))
if A.locale ~= "zhTW" then return end

-----------------------------
--	zhTW client
-----------------------------
-- main frame
L.gui.threat		= "威脅"

-- config frame
L.default			= "預設值"
