local A, C, L, _ = unpack(select(2, ...))
if A.locale ~= "deDE" then return end

-----------------------------
--	deDE client
-----------------------------
-- main frame
L.gui.threat		= "Bedrohung"

-- config frame
L.default			= "Standard"
