local A, C, L, _ = unpack(select(2, ...))
if A.locale ~= "koKR" then return end

-----------------------------
--	koKR client
-----------------------------
-- main frame
L.gui.threat		= "위협"

-- config frame
L.default			= "기본"
