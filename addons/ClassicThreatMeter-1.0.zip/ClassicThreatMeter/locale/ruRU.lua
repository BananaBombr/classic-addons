local A, C, L, _ = unpack(select(2, ...))
if A.locale ~= "ruRU" then return end

-----------------------------
--	ruRU client
-----------------------------
-- main frame
L.gui.threat		= "Угроза"

-- config frame
L.default			= "По умолчанию"
