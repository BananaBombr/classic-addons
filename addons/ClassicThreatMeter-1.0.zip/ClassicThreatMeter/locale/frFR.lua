local A, C, L, _ = unpack(select(2, ...))
if A.locale ~= "frFR" then return end

-----------------------------
--	frFR client
-----------------------------
-- main frame
L.gui.threat		= "Menace"

-- config frame
L.default			= "Défaut"
