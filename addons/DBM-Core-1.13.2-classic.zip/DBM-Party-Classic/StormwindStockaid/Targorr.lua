local mod	= DBM:NewMod("Targorr", "DBM-Party-Classic", 15)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20190614210311")
mod:SetCreatureID(1696)

mod:RegisterCombat("combat")
