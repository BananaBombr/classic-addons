﻿if GetLocale() ~= "deDE" then return end
local L

-------------------------
--  Blackfathom Deeps  --
-----------------------------
--  Ghamoo'Ra  --
-----------------------------
L = DBM:GetModLocalization(368)
