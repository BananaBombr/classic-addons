-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'koKR') then return end

local L = _G[addon].L

