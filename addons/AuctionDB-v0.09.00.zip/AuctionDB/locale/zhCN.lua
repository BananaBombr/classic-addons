-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'zhCN') then return end

local L = _G[addon].L

