-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'enUS') then return end

local L = _G[addon].L
L["|cFF99E5FFLeft|r click to scan or open offline"] = true
L["|cFF99E5FFRight|r click for options"] = true
L["10 sec"] = true
L["2 sec"] = true
L[ [=[Action Button!

|cFF99E5FFLeft|r click (or hit space/return/iwt) to:]=] ] = true
L["AH closed"] = true
L["AH Scan"] = true
L["AHDB Open"] = true
L["AHDB: click the button, or hit space or enter or IWT to "] = true
L["Auction House DataBase addon key bindings"] = true
L["Auction House DataBase: records DB history, offline queries and more."] = true
L["AuctionDB bug report open: "] = true
L["AuctionDB options"] = true
L["auctioneer"] = true
L["Auto Save/Reload"] = true
L["Auto Scan"] = true
L["Auto scan delay"] = true
L["Automatically prompts for /reload in order to save the DataBase at the end of the scan"] = true
L["Automatically scan the AH whenever possible, unless the |cFF99E5FFShift|r key is held"] = true
L["Bug Report"] = true
L["Bug report from slash command"] = true
L["Can't do a full scan at this point, try later..."] = true
L["Can't start AH scan, not at AH"] = true
L["Debug level"] = true
L["Development, troubleshooting and advanced options:"] = true
L["Drag to move this button."] = true
L["Get Information to submit a bug."] = true
L["How long to wait for cancellation before scan start"] = true
L["None"] = true
L["Please submit on discord or https://|cFF99E5FFbit.ly/ahbug|r or email"] = true
L["Reset minimap button"] = true
L["Resets the minimap button to back to initial default location"] = true
L["Save the scan data to SavedVariables"] = true
L["Sets the debug level"] = true
L["Shift key is down so we're not starting a scan."] = true
L["Show new items"] = true
L["Shows never seen before items found in scan up to these many"] = true
L["Start a full manual scan now"] = true
L["Start a full scan now!"] = true
L["Starting full scan (hold shift next time to prevent it or turn off auto scan)"] = true
L["Target the Auctioneer"] = true
L["These options let you control the behavior of AuctionDB"] = true

