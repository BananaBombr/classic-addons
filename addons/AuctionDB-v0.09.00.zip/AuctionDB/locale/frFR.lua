-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'frFR') then return end

local L = _G[addon].L
L["|cFF99E5FFLeft|r click to scan or open offline"] = "Cliquez |cFF99E5FFGauche|r pour Scanner ou ouvrir hors ligne"
L["10 sec"] = true

