-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'deDE') then return end

local L = _G[addon].L

