-- Generated file, do not edit.
local addon, _ns = ...

if (GetLocale() ~= 'ptBR') then return end

local L = _G[addon].L
L["|cFF99E5FFLeft|r click to scan or open offline"] = "Clique |cFF99E5FFEsq|r para escanear ou abrir offline"
L["|cFF99E5FFRight|r click for options"] = "Clique |cFF99E5FFDir|r para abrir as opções"
L["10 sec"] = "10 seg"
L["2 sec"] = "2 seg"
L["AH closed"] = "Casa de leilões fechada"
L["AH Scan"] = "Escanear a casa de leilões"
L["AHDB Open"] = "AHDB aberto"
L["AHDB: click the button, or hit space or enter or IWT to "] = "AHDB: Clique no botão, aperte espaço, enter ou IWT para"
L["AuctionDB options"] = "AuctionDB opções"

