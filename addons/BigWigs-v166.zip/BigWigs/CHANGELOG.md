# BigWigs

## [v166](https://github.com/BigWigsMods/BigWigs/tree/v166) (2019-08-22)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v165...v166)

- bump  
- Update zhCN (#708)  
- EternalPalace/QueenAzshara: Update Indomitable timer in Mythic and Fix Arcane Detonation timers in stage 3 in Mythic  
- EternalPalace/QueenAzshara: Prep for Encounter Spawn event.  
- Core/Constants: Improve CRLF detection  
