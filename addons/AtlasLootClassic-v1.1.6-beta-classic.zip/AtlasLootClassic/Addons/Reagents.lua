local ALName, ALPrivate = ...

local _G = getfenv(0)
local AtlasLoot = _G.AtlasLoot
local Addons = AtlasLoot.Addons
local AL = AtlasLoot.Locales
local Reagents = Addons:RegisterNewAddon("Reagents")
local Tooltip = AtlasLoot.Tooltip

-- lua


-- WoW


-- locals


-- Addon
Reagents.DbDefaults = {

}

--Reagents.GlobalDbDefaults = {}


function Reagents.OnInitialize()

end

function Reagents:OnProfileChanged()

end

function Reagents:OnStatusChanged()

end



Reagents:Finalize()